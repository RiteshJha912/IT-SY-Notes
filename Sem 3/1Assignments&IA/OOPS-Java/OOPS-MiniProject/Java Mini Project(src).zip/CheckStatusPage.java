import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class CheckStatusPage extends JFrame {

    private JTextField emailField;
    private JButton checkButton, backButton;
    private JLabel resultLabel;

    public CheckStatusPage() {
        setTitle("Check Application Status");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel emailLabel = new JLabel("Enter Your Email:");
        emailField = new JTextField(20);
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(emailLabel, gbc);

        gbc.gridx = 1;
        add(emailField, gbc);

        checkButton = new JButton("Check Status");
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        add(checkButton, gbc);

        resultLabel = new JLabel("");
        gbc.gridy = 2;
        add(resultLabel, gbc);

        backButton = new JButton("Back");
        gbc.gridy = 3;
        add(backButton, gbc);

        checkButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String email = emailField.getText().trim();
                if (email.isEmpty()) {
                    JOptionPane.showMessageDialog(CheckStatusPage.this, "Please enter an email!", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    checkApplicationStatus(email);
                }
            }
        });

        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new RoleSelectionPage().setVisible(true);
            }
        });
    }

    private void checkApplicationStatus(String email) {
        String url = "jdbc:mysql://localhost:3306/college_system";
        String username = "root";
        String password = "root";

        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            String query = "SELECT status FROM students WHERE email = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String status = rs.getString("status");
                if ("Approved".equals(status)) {
                    resultLabel.setText("Congratulations! Your application has been approved. Please visit the Somaiya Vidyavihar University to confirm your admission.");
                } else if ("Rejected".equals(status)) {
                    resultLabel.setText("We regret to inform you that your application was reviewed but was not found suitable. Thank you for your interest in Somaiya Vidyavihar University.");
                } else {
                    resultLabel.setText("Application Status: Pending");
                }
            } else {
                resultLabel.setText("No application found for the given email.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(CheckStatusPage.this, "Error fetching application status!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new CheckStatusPage().setVisible(true);
    }
}
