    import javax.swing.*;
    import java.awt.*;
    import java.awt.event.*;
    import java.sql.Connection;
    import java.sql.DriverManager;
    import java.sql.PreparedStatement;
    import java.sql.SQLException;

    public class Form extends JFrame {

        private JTextField nameField, emailField, ageField, marksField;
        private JComboBox<String> courseDropdown;
        private JButton submitButton, backButton;

        public Form(String role) {
            // Create the form frame
            setTitle(role + " Enrollment Form");
            setSize(500, 350);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setLayout(new GridBagLayout());  // Using GridBagLayout for more control
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(5, 5, 5, 5);  // Padding for spacing between components

            // Welcome message at the top
            JLabel welcomeLabel = new JLabel("Welcome Student, please fill the below form for admission.");
            welcomeLabel.setFont(new Font("Arial", Font.BOLD, 16));
            welcomeLabel.setHorizontalAlignment(SwingConstants.CENTER);
            welcomeLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
            gbc.gridwidth = 2;  // Span across two columns
            gbc.gridx = 0;
            gbc.gridy = 0;
            add(welcomeLabel, gbc);

            // Name field
            JLabel nameLabel = new JLabel("Name:");
            nameLabel.setFont(new Font("Arial", Font.PLAIN, 14));
            nameField = new JTextField(20);
            nameLabel.setLabelFor(nameField);  // Associate label with field

            gbc.gridwidth = 1;  // Reset gridwidth to 1 for next fields
            gbc.gridx = 0;
            gbc.gridy = 1;
            add(nameLabel, gbc);

            gbc.gridx = 1;
            gbc.gridy = 1;
            nameField.setPreferredSize(new Dimension(200, 30));  // Smaller input field size
            add(nameField, gbc);

            // Somaiya Email field
            JLabel emailLabel = new JLabel("Personal Email:");
            emailLabel.setFont(new Font("Arial", Font.PLAIN, 14));
            emailField = new JTextField(20);
            emailLabel.setLabelFor(emailField);  // Associate label with field

            gbc.gridx = 0;
            gbc.gridy = 2;
            add(emailLabel, gbc);

            gbc.gridx = 1;
            gbc.gridy = 2;
            emailField.setPreferredSize(new Dimension(200, 30));
            add(emailField, gbc);

            // Marks field (NEW FIELD)
            JLabel marksLabel = new JLabel("Marks (0-100):");
            marksLabel.setFont(new Font("Arial", Font.PLAIN, 14));
            marksField = new JTextField(5);
            marksLabel.setLabelFor(marksField);  // Associate label with field

            gbc.gridx = 0;
            gbc.gridy = 3;
            add(marksLabel, gbc);

            gbc.gridx = 1;
            gbc.gridy = 3;
            marksField.setPreferredSize(new Dimension(100, 30));
            add(marksField, gbc);

            // Age field
            JLabel ageLabel = new JLabel("Age:");
            ageLabel.setFont(new Font("Arial", Font.PLAIN, 14));
            ageField = new JTextField(5);
            ageLabel.setLabelFor(ageField);  // Associate label with field

            gbc.gridx = 0;
            gbc.gridy = 4;
            add(ageLabel, gbc);

            gbc.gridx = 1;
            gbc.gridy = 4;
            ageField.setPreferredSize(new Dimension(100, 30));  // Smaller input box
            add(ageField, gbc);

            // Course dropdown
            JLabel courseLabel = new JLabel("Course:");
            courseLabel.setFont(new Font("Arial", Font.PLAIN, 14));
            String[] courses = {
                    "Computer Engineering(Comps)",
                    "Information Technology Engineering(IT)",
                    "Artificial Intelligence and Data Science(AI&DS)",
                    "Computer & Communication Engineering(CCE)",
                    "Electronics and Telecommunication Engineering(EXTC)"
            };
            courseDropdown = new JComboBox<>(courses);
            courseLabel.setLabelFor(courseDropdown);  // Associate label with field

            gbc.gridx = 0;
            gbc.gridy = 5;
            add(courseLabel, gbc);

            gbc.gridx = 1;
            gbc.gridy = 5;
            courseDropdown.setPreferredSize(new Dimension(300, 30));  // Increased dropdown width
            add(courseDropdown, gbc);

            // Submit button
            submitButton = new JButton("Submit");
            submitButton.setFont(new Font("Arial", Font.PLAIN, 14));
            gbc.gridwidth = 2;  // Make the button span across two columns
            gbc.gridx = 0;
            gbc.gridy = 6;
            gbc.insets = new Insets(20, 5, 5, 5);  // Add some extra padding before the button
            add(submitButton, gbc);

            // Back button
            backButton = new JButton("Back");
            backButton.setFont(new Font("Arial", Font.PLAIN, 14));
            gbc.gridx = 0;
            gbc.gridy = 7;
            gbc.insets = new Insets(10, 5, 10, 5);  // Padding for the back button
            add(backButton, gbc);

            // Action for submit button
            submitButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    String name = nameField.getText();
                    String email = emailField.getText();
                    String age = ageField.getText();
                    String marks = marksField.getText();
                    String course = courseDropdown.getSelectedItem().toString();

                    // Validate marks field (should be between 0 and 100)
                    try {
                        int marksValue = Integer.parseInt(marks);
                        if (marksValue < 0 || marksValue > 100) {
                            throw new NumberFormatException();
                        }
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(Form.this, "Please enter marks between 0 and 100.", "Invalid Marks", JOptionPane.ERROR_MESSAGE);
                        return;  // Stop form submission if validation fails
                    }

                    if (name.isEmpty() || email.isEmpty() || age.isEmpty() || marks.isEmpty()) {
                        // Display an error if fields are empty
                        JOptionPane.showMessageDialog(Form.this, "Please fill out all fields!", "Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                        saveData(name, email, age, marks, course);  // Save student data to database
                        // Show confirmation message after successful submission
                        JOptionPane.showMessageDialog(Form.this, "Form has been submitted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                        // Optionally, you can clear the form after submission
                        nameField.setText("");
                        emailField.setText("");
                        ageField.setText("");
                        marksField.setText("");
                        courseDropdown.setSelectedIndex(0);
                    }
                }
            });

            // Action for back button
            backButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    // Close current window and return to RoleSelection page
                    dispose();  // Close the form window
                    new RoleSelectionPage().setVisible(true);  // Open the RoleSelection page
                }
            });
        }

        // Method to save form data to MySQL
        private void saveData(String name, String email, String age, String marks, String course) {
            try {
                // Database connection details
                String url = "jdbc:mysql://localhost:3306/college_system";
                String username = "root";  // Change this to your database username
                String password = "root";  // Change this to your database password

                // Create a connection to the database
                Connection conn = DriverManager.getConnection(url, username, password);

                // SQL query to insert data into the student table
                String query = "INSERT INTO students (name, email, age, marks, course) VALUES (?, ?, ?, ?, ?)";

                // Create a PreparedStatement
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1, name);
                stmt.setString(2, email);
                stmt.setString(3, age);
                stmt.setString(4, marks);
                stmt.setString(5, course);

                // Execute the insert operation
                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Data saved successfully!");
                } else {
                    System.out.println("Failed to save data.");
                }

                // Close the connection
                stmt.close();
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(Form.this, "Error saving data to database!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        public static void main(String[] args) {
            new Form("Student").setVisible(true);
        }
    }
