import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class RoleSelectionPage extends JFrame {

    public RoleSelectionPage() {
        // Setup the frame
        setTitle("Select Role");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Add logo image at the top center (make sure to put the logo image in the project folder)
        ImageIcon logoIcon = new ImageIcon("logo.png"); // Logo image file
        Image logoImage = logoIcon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);  // Resize the image
        logoIcon = new ImageIcon(logoImage);  // Update the ImageIcon with the resized image
        JLabel logoLabel = new JLabel(logoIcon);
        logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(logoLabel, BorderLayout.NORTH);

        // Create a panel for "Select your role" and buttons
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 1, 10, 10));  // Grid layout for better centering and spacing

        // "Select your role" label
        JLabel label = new JLabel("Select your role");
        JLabel label2 = new JLabel("Welcome to Somaiya Vidyavihar Admission Portal ");
        label.setFont(new Font("Arial", Font.BOLD, 18));
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label2.setFont(new Font("Arial", Font.BOLD, 18));
        label2.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(label2);
        panel.add(label);

        // Role selection buttons
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton studentButton = new JButton("Student");
        JButton adminButton = new JButton("Admin");
        JButton statusCheckButton = new JButton("Check Application Status");

        // Customize the buttons
        studentButton.setFont(new Font("Arial", Font.PLAIN, 14));
        adminButton.setFont(new Font("Arial", Font.PLAIN, 14));
        statusCheckButton.setFont(new Font("Arial", Font.PLAIN, 14));
        studentButton.setPreferredSize(new Dimension(120, 40));
        adminButton.setPreferredSize(new Dimension(120, 40));
        statusCheckButton.setPreferredSize(new Dimension(180, 40));

        // Add buttons to buttonPanel
        buttonPanel.add(studentButton);
        buttonPanel.add(adminButton);
        buttonPanel.add(statusCheckButton);

        // Add buttonPanel to the main panel
        panel.add(buttonPanel);

        // Button action listeners
        studentButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Form("Student").setVisible(true);  // Show Student Form
                dispose();  // Close the role selection window
            }
        });

        adminButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AdminView().setVisible(true);  // Show Admin View
                dispose();  // Close the role selection window
            }
        });

        // Action listener for status check button
        statusCheckButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new CheckStatusPage().setVisible(true);  // Show Check Status Page
                dispose();  // Close the role selection window
            }
        });

        // Add the panel to the center of the frame
        add(panel, BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        // Show role selection page
        new RoleSelectionPage().setVisible(true);
    }
}
