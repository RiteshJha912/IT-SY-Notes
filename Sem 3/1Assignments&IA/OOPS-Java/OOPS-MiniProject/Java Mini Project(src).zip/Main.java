import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Main {
    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/college_system";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "root";

    public static void main(String[] args) {
        JFrame frame = new JFrame("Registration Form with MySQL");
        frame.setSize(400, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(8, 2));

        JLabel idLabel = new JLabel("ID:");
        JTextField idField = new JTextField();
        JLabel nameLabel = new JLabel("Name:");
        JTextField nameField = new JTextField();
        JLabel genderLabel = new JLabel("Gender:");
        JRadioButton male = new JRadioButton("Male");
        JRadioButton female = new JRadioButton("Female");
        ButtonGroup genderGroup = new ButtonGroup();
        genderGroup.add(male);
        genderGroup.add(female);
        JLabel hobbyLabel = new JLabel("Hobbies:");
        JCheckBox reading = new JCheckBox("Reading");
        JCheckBox traveling = new JCheckBox("Traveling");
        JCheckBox coding = new JCheckBox("Coding");
        JLabel countryLabel = new JLabel("Country:");
        String[] countries = {"India", "USA", "UK", "Canada"};
        JComboBox<String> countryDropdown = new JComboBox<>(countries);

        JButton insertButton = new JButton("Insert");
        JButton updateButton = new JButton("Update");
        JButton deleteButton = new JButton("Delete");
        JButton searchButton = new JButton("Search");

        // Action for Insert button
        insertButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String gender = male.isSelected() ? "Male" : (female.isSelected() ? "Female" : "Not selected");
                String hobbies = "";
                if (reading.isSelected()) hobbies += "Reading ";
                if (traveling.isSelected()) hobbies += "Traveling ";
                if (coding.isSelected()) hobbies += "Coding ";
                String country = (String) countryDropdown.getSelectedItem();

                try {
                    Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                    String sql = "INSERT INTO users (name, gender, hobbies, country) VALUES (?, ?, ?, ?)";
                    PreparedStatement stmt = connection.prepareStatement(sql);
                    stmt.setString(1, name);
                    stmt.setString(2, gender);
                    stmt.setString(3, hobbies.trim());
                    stmt.setString(4, country);
                    stmt.executeUpdate();
                    JOptionPane.showMessageDialog(frame, "Record Inserted Successfully!");
                    connection.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        // Action for Update button
        updateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String id = idField.getText();
                String name = nameField.getText();
                String gender = male.isSelected() ? "Male" : (female.isSelected() ? "Female" : "Not selected");
                String hobbies = "";
                if (reading.isSelected()) hobbies += "Reading ";
                if (traveling.isSelected()) hobbies += "Traveling ";
                if (coding.isSelected()) hobbies += "Coding ";
                String country = (String) countryDropdown.getSelectedItem();

                try {
                    Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                    String sql = "UPDATE users SET name=?, gender=?, hobbies=?, country=? WHERE id=?";
                    PreparedStatement stmt = connection.prepareStatement(sql);
                    stmt.setString(1, name);
                    stmt.setString(2, gender);
                    stmt.setString(3, hobbies.trim());
                    stmt.setString(4, country);
                    stmt.setInt(5, Integer.parseInt(id));
                    int rowsUpdated = stmt.executeUpdate();
                    if (rowsUpdated > 0) {
                        JOptionPane.showMessageDialog(frame, "Record Updated Successfully!");
                    } else {
                        JOptionPane.showMessageDialog(frame, "Record Not Found!");
                    }
                    connection.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        // Action for Delete button
        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String id = idField.getText();

                try {
                    Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                    String sql = "DELETE FROM users WHERE id=?";
                    PreparedStatement stmt = connection.prepareStatement(sql);
                    stmt.setInt(1, Integer.parseInt(id));
                    int rowsDeleted = stmt.executeUpdate();
                    if (rowsDeleted > 0) {
                        JOptionPane.showMessageDialog(frame, "Record Deleted Successfully!");
                    } else {
                        JOptionPane.showMessageDialog(frame, "Record Not Found!");
                    }
                    connection.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        // Action for Search button
        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String id = idField.getText();

                try {
                    Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                    String sql = "SELECT * FROM users WHERE id=?";
                    PreparedStatement stmt = connection.prepareStatement(sql);
                    stmt.setInt(1, Integer.parseInt(id));
                    ResultSet rs = stmt.executeQuery();
                    if (rs.next()) {
                        nameField.setText(rs.getString("name"));
                        if ("Male".equals(rs.getString("gender"))) {
                            male.setSelected(true);
                        } else {
                            female.setSelected(true);
                        }
                        String[] hobbies = rs.getString("hobbies").split(" ");
                        reading.setSelected(false);
                        traveling.setSelected(false);
                        coding.setSelected(false);
                        for (String hobby : hobbies) {
                            if ("Reading".equals(hobby)) reading.setSelected(true);
                            if ("Traveling".equals(hobby)) traveling.setSelected(true);
                            if ("Coding".equals(hobby)) coding.setSelected(true);
                        }
                        countryDropdown.setSelectedItem(rs.getString("country"));
                    } else {
                        JOptionPane.showMessageDialog(frame, "Record Not Found!");
                    }
                    connection.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        // Adding components to the frame
        frame.add(idLabel);
        frame.add(idField);
        frame.add(nameLabel);
        frame.add(nameField);
        frame.add(genderLabel);
        frame.add(male);
        frame.add(new JLabel());
        frame.add(female);
        frame.add(hobbyLabel);
        frame.add(reading);
        frame.add(traveling);
        frame.add(coding);
        frame.add(countryLabel);
        frame.add(countryDropdown);
        frame.add(insertButton);
        frame.add(updateButton);
        frame.add(deleteButton);
        frame.add(searchButton);

        frame.setVisible(true);
    }
}
