import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;

public class AdminView extends JFrame {

    private JTable studentTable;
    private DefaultTableModel tableModel;

    public AdminView() {
        setTitle("Admin View - Enrolled Students");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JLabel welcomeLabel = new JLabel("Welcome Admin!", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        welcomeLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(welcomeLabel, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(new String[]{"ID", "Name", "Email", "Age", "Course", "Status", "Action"}, 0);
        studentTable = new JTable(tableModel);
        studentTable.setFont(new Font("Arial", Font.PLAIN, 14));
        studentTable.setRowHeight(25);
        JScrollPane tableScrollPane = new JScrollPane(studentTable);
        add(tableScrollPane, BorderLayout.CENTER);

        viewStudents();
    }

    private void viewStudents() {
        String url = "jdbc:mysql://localhost:3306/college_system";
        String user = "root";
        String password = "";

        try (Connection con = DriverManager.getConnection(url, user, password)) {
            String query = "SELECT * FROM students";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            tableModel.setRowCount(0);

            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                row.add(rs.getInt("id"));
                row.add(rs.getString("name"));
                row.add(rs.getString("email"));
                row.add(rs.getInt("age"));
                row.add(rs.getString("course"));
                String status = rs.getString("status");
                row.add(status != null ? status : "Pending");

                JPanel actionPanel = new JPanel();
                JButton approveButton = new JButton("Approve");
                JButton rejectButton = new JButton("Reject");

                approveButton.addActionListener(e -> {
                    try {
                        updateStatus(rs.getInt("id"), "Approved");
                    } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(this, "Error updating status: " + ex.getMessage());
                    }
                });
                rejectButton.addActionListener(e -> {
                    try {
                        updateStatus(rs.getInt("id"), "Rejected");
                    } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(this, "Error updating status: " + ex.getMessage());
                    }
                });

                if ("Pending".equals(status)) {
                    actionPanel.add(approveButton);
                    actionPanel.add(rejectButton);
                } else {
                    actionPanel.add(new JLabel(status));
                }

                row.add(actionPanel);
                tableModel.addRow(row);
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void updateStatus(int id, String newStatus) throws SQLException {
        String url = "jdbc:mysql://localhost:3306/college_system";
        String user = "root";
        String password = "";

        try (Connection con = DriverManager.getConnection(url, user, password)) {
            String updateQuery = "UPDATE students SET status = ? WHERE id = ?";
            PreparedStatement stmt = con.prepareStatement(updateQuery);
            stmt.setString(1, newStatus);
            stmt.setInt(2, id);
            stmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Status updated to: " + newStatus);
            viewStudents();
        }
    }

    public static void main(String[] args) {
        new AdminView().setVisible(true);
    }
}
