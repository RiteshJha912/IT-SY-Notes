class Graph {
    constructor(canvas) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
        this.nodes = [];
        this.edges = [];
        this.selectedNodes = [];
        this.isDeleting = false;
        this.isRunning = false;
        this.steps = [];
        this.currentStep = 0;
        this.totalWeight = 0;
        
        this.setupCanvas();
        this.addEventListeners();
    }

    setupCanvas() {
        this.canvas.width = this.canvas.offsetWidth;
        this.canvas.height = this.canvas.offsetHeight;
        this.draw();
    }

    addEventListeners() {
        window.addEventListener('resize', () => this.setupCanvas());
        
        this.canvas.addEventListener('click', (e) => {
            if (this.isRunning) return;
            
            const rect = this.canvas.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const clickedNode = this.findNode(x, y);
            
            if (clickedNode) {
                if (this.isDeleting) {
                    this.deleteNode(clickedNode);
                } else {
                    this.handleNodeSelection(clickedNode);
                }
            } else if (!this.isDeleting) {
                this.addNode(x, y);
            }
        });
    }

    findNode(x, y) {
        return this.nodes.find(node => 
            Math.sqrt(Math.pow(node.x - x, 2) + Math.pow(node.y - y, 2)) < 20
        );
    }

    addNode(x, y) {
        const id = String.fromCharCode(65 + this.nodes.length);
        this.nodes.push({ id, x, y });
        this.draw();
    }

    deleteNode(node) {
        this.nodes = this.nodes.filter(n => n.id !== node.id);
        this.edges = this.edges.filter(e => 
            e.source !== node.id && e.destination !== node.id
        );
        this.isDeleting = false;
        document.getElementById('delete-mode').classList.remove('active');
        this.draw();
    }

    handleNodeSelection(node) {
        if (this.selectedNodes.includes(node.id)) {
            this.selectedNodes = this.selectedNodes.filter(id => id !== node.id);
        } else {
            this.selectedNodes.push(node.id);
            if (this.selectedNodes.length === 2) {
                const weight = parseInt(prompt('Enter edge weight:') || '0');
                if (weight) {
                    this.edges.push({
                        source: this.selectedNodes[0],
                        destination: this.selectedNodes[1],
                        weight
                    });
                }
                this.selectedNodes = [];
            }
        }
        this.draw();
    }

    draw() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Draw edges
        this.edges.forEach(edge => {
            const sourceNode = this.nodes.find(n => n.id === edge.source);
            const destNode = this.nodes.find(n => n.id === edge.destination);
            
            if (sourceNode && destNode) {
                this.ctx.beginPath();
                this.ctx.moveTo(sourceNode.x, sourceNode.y);
                this.ctx.lineTo(destNode.x, destNode.y);
                
                const isIncluded = this.steps.slice(0, this.currentStep + 1).some(
                    step => (step.source === edge.source && step.destination === edge.destination) ||
                           (step.source === edge.destination && step.destination === edge.source)
                );
                
                this.ctx.strokeStyle = isIncluded ? '#22c55e' : '#94a3b8';
                this.ctx.lineWidth = isIncluded ? 3 : 1;
                this.ctx.stroke();

                // Draw weight
                const midX = (sourceNode.x + destNode.x) / 2;
                const midY = (sourceNode.y + destNode.y) / 2;
                this.ctx.fillStyle = '#1e293b';
                this.ctx.font = '14px sans-serif';
                this.ctx.textAlign = 'center';
                this.ctx.textBaseline = 'middle';
                this.ctx.fillText(edge.weight.toString(), midX, midY);
            }
        });

        // Draw nodes
        this.nodes.forEach(node => {
            this.ctx.beginPath();
            this.ctx.arc(node.x, node.y, 20, 0, 2 * Math.PI);
            
            const isSelected = this.selectedNodes.includes(node.id);
            const isActive = this.steps[this.currentStep]?.source === node.id ||
                           this.steps[this.currentStep]?.destination === node.id;
            
            if (isActive) {
                this.ctx.fillStyle = '#3b82f6';
                this.animateNode(node);
            } else {
                this.ctx.fillStyle = isSelected ? '#60a5fa' : '#ffffff';
            }
            
            this.ctx.fill();
            this.ctx.strokeStyle = '#2563eb';
            this.ctx.lineWidth = 2;
            this.ctx.stroke();
            
            this.ctx.fillStyle = '#1e293b';
            this.ctx.font = '16px sans-serif';
            this.ctx.textAlign = 'center';
            this.ctx.textBaseline = 'middle';
            this.ctx.fillText(node.id, node.x, node.y);
        });
    }

    animateNode(node) {
        const originalRadius = 20;
        const maxRadius = 25;
        const duration = 500;
        const startTime = performance.now();

        const animate = (currentTime) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            
            const radius = originalRadius + (maxRadius - originalRadius) * 
                Math.sin(progress * Math.PI) * Math.exp(-progress * 2);
            
            this.ctx.beginPath();
            this.ctx.arc(node.x, node.y, radius, 0, 2 * Math.PI);
            this.ctx.fillStyle = 'rgba(59, 130, 246, 0.001)';
            this.ctx.fill();
            this.ctx.stroke();

            if (progress < 1) {
                requestAnimationFrame(animate);
            }
        };

        requestAnimationFrame(animate);
    }

    parseInput(input) {
        const lines = input.trim().split('\n');
        const newNodes = new Set();
        const newEdges = [];

        lines.forEach(line => {
            const [source, dest, weight] = line.trim().split(' ');
            if (source && dest && weight) {
                newNodes.add(source);
                newNodes.add(dest);
                newEdges.push({ source, destination: dest, weight: parseInt(weight) });
            }
        });

        const nodeArray = Array.from(newNodes);
        const radius = Math.min(this.canvas.width, this.canvas.height) / 3;
        const angleStep = (2 * Math.PI) / nodeArray.length;
        const centerX = this.canvas.width / 2;
        const centerY = this.canvas.height / 2;

        this.nodes = nodeArray.map((id, index) => ({
            id,
            x: centerX + radius * Math.cos(index * angleStep),
            y: centerY + radius * Math.sin(index * angleStep)
        }));
        
        this.edges = newEdges;
        this.draw();
    }

    findParent(parent, node) {
        if (parent[node] === node) return node;
        return this.findParent(parent, parent[node]);
    }

    kruskalMST() {
        const sortedEdges = [...this.edges].sort((a, b) => a.weight - b.weight);
        const parent = {};
        this.nodes.forEach(node => parent[node.id] = node.id);
        const mst = [];

        sortedEdges.forEach(edge => {
            const sourceParent = this.findParent(parent, edge.source);
            const destParent = this.findParent(parent, edge.destination);

            if (sourceParent !== destParent) {
                mst.push(edge);
                parent[sourceParent] = destParent;
            }
        });

        return mst;
    }

    primMST() {
        if (this.nodes.length === 0) return [];
        
        const visited = new Set();
        const mst = [];
        visited.add(this.nodes[0].id);

        while (visited.size < this.nodes.length) {
            let minEdge = null;
            let minWeight = Infinity;

            this.edges.forEach(edge => {
                const isSourceVisited = visited.has(edge.source);
                const isDestVisited = visited.has(edge.destination);

                if ((isSourceVisited && !isDestVisited) || (!isSourceVisited && isDestVisited)) {
                    if (edge.weight < minWeight) {
                        minWeight = edge.weight;
                        minEdge = edge;
                    }
                }
            });

            if (minEdge) {
                mst.push(minEdge);
                visited.add(visited.has(minEdge.source) ? minEdge.destination : minEdge.source);
            }
        }

        return mst;
    }

    async runAlgorithm(algorithm) {
        this.isRunning = true;
        this.currentStep = 0;
        this.totalWeight = 0;
        this.steps = algorithm === 'kruskal' ? this.kruskalMST() : this.primMST();
        
        const weightDisplay = document.getElementById('weight-display');
        weightDisplay.classList.remove('hidden');
        
        for (let i = 0; i < this.steps.length; i++) {
            this.currentStep = i;
            this.totalWeight = this.steps.slice(0, i + 1)
                .reduce((sum, edge) => sum + edge.weight, 0);
            document.getElementById('total-weight').textContent = this.totalWeight;
            this.draw();
            await new Promise(resolve => setTimeout(resolve, 1000));
        }
    }

    reset() {
        this.isRunning = false;
        this.currentStep = 0;
        this.steps = [];
        this.totalWeight = 0;
        this.selectedNodes = [];
        this.isDeleting = false;
        document.getElementById('weight-display').classList.add('hidden');
        document.getElementById('delete-mode').classList.remove('active');
        this.draw();
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    const canvas = document.getElementById('graph-canvas');
    const graph = new Graph(canvas);

    // Button handlers
    document.getElementById('parse').addEventListener('click', () => {
        const input = document.getElementById('graph-input').value;
        graph.parseInput(input);
    });

    document.getElementById('run').addEventListener('click', () => {
        const algorithm = document.getElementById('algorithm').value;
        graph.runAlgorithm(algorithm);
    });

    document.getElementById('reset').addEventListener('click', () => {
        graph.reset();
    });

    document.getElementById('delete-mode').addEventListener('click', () => {
        graph.isDeleting = !graph.isDeleting;
        document.getElementById('delete-mode').classList.toggle('active');
    });
    
});