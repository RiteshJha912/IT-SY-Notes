// Initialize features when DOM is fully loaded
document.addEventListener("DOMContentLoaded", function () {
    console.log("DOM Loaded - Initializing Features...");

    initBackToTopButton();
    insertDynamicDate();
    initSearchBar();
    applySeverityLabels();
    initComplaintForm();  // Initialize complaint form functionality
});

// ========================== BACK TO TOP BUTTON ==========================
function initBackToTopButton() {
    const backToTop = document.createElement("button");
    backToTop.innerText = "⬆ Back to Top";
    backToTop.style.position = "fixed";
    backToTop.style.bottom = "20px";
    backToTop.style.right = "20px";
    backToTop.style.padding = "10px 15px";
    backToTop.style.background = "#8E24AA";
    backToTop.style.color = "white";
    backToTop.style.border = "none";
    backToTop.style.borderRadius = "8px";
    backToTop.style.cursor = "pointer";
    backToTop.style.display = "none";
    backToTop.style.zIndex = "1000";

    document.body.appendChild(backToTop);

    backToTop.addEventListener("click", scrollToTop);
    window.addEventListener("scroll", toggleBackToTopVisibility);
}

function scrollToTop() {
    window.scrollTo({ top: 0, behavior: "smooth" });
}

function toggleBackToTopVisibility() {
    const backToTop = document.querySelector("button");
    if (window.scrollY > 200) {
        backToTop.style.display = "block";
    } else {
        backToTop.style.display = "none";
    }
}

// ========================== DYNAMIC DATE IN FOOTER ==========================
function insertDynamicDate() {
    const footer = document.querySelector("footer p");
    if (footer) {
        const now = new Date();
        const fullDate = now.toDateString(); // Example: "Thu Mar 27 2025"
        footer.innerHTML = ` ${fullDate} <br/> © Cyber Awareness<br/>All rights reserved`;
    }
}

// ========================== SEARCH BAR FUNCTIONALITY (ONLY FOR ADVISORY PAGE) ==========================
function initSearchBar() {
    if (!window.location.pathname.includes("advisory.html")) return;

    const searchInput = document.createElement("input");
    searchInput.type = "text";
    searchInput.placeholder = "Search advisories...";
    searchInput.style.margin = "20px auto";
    searchInput.style.padding = "10px";
    searchInput.style.width = "50%";
    searchInput.style.display = "block";
    searchInput.style.border = "1px solid #ccc";
    searchInput.style.borderRadius = "8px";
    searchInput.style.textAlign = "center";

    document.querySelector(".container").insertBefore(searchInput, document.querySelector(".container").children[2]);
    searchInput.addEventListener("input", filterAdvisories);
}

function filterAdvisories() {
    let searchValue = this.value.toLowerCase();
    document.querySelectorAll(".box").forEach(box => {
        let title = box.querySelector("h3").innerText.toLowerCase();
        box.style.display = title.includes(searchValue) ? "inline-block" : "none";
    });
}

// ========================== THREAT SEVERITY INDICATOR (ONLY FOR ADVISORY PAGE) ==========================
function applySeverityLabels() {
    if (!window.location.pathname.includes("advisory.html")) return;

    document.querySelectorAll(".box").forEach(box => {
        const severityLevels = ["Low", "Medium", "High"];
        const severityColors = { "Low": "green", "Medium": "orange", "High": "red" };

        const severity = severityLevels[Math.floor(Math.random() * severityLevels.length)];  // Random severity
        const severityLabel = document.createElement("p");
        severityLabel.innerText = `Severity: ${severity}`;
        severityLabel.style.color = "white";
        severityLabel.style.backgroundColor = severityColors[severity];
        severityLabel.style.padding = "5px";
        severityLabel.style.borderRadius = "5px";
        severityLabel.style.fontWeight = "bold";
        severityLabel.style.display = "inline-block";

        box.appendChild(severityLabel);
    });
}




// ========================== OTHER EVENT LISTENERS ==========================
// Onblur event: Alerts when input loses focus (ONLY for text fields)
document.querySelectorAll("input[type='text']").forEach(input => {
    input.addEventListener("blur", function () {
        alert(`You left the field: ${this.name}`);
    });
});

// Onreset event: Confirms before resetting the form
document.querySelectorAll("form").forEach(form => {
    form.addEventListener("reset", function (event) {
        if (!confirm("Are you sure you want to reset the form?")) {
            event.preventDefault();
        }
    });
});

// Onmouseover event: Changes color when hovering over advisory boxes
document.querySelectorAll(".box").forEach(box => {
    box.addEventListener("mouseover", function () {
        this.style.backgroundColor = "#dfe6f1";
    });

    // Onmouseout event: Resets the background color
    box.addEventListener("mouseout", function () {
        this.style.backgroundColor = "#ffffff";
    });

    // Onclick event: Changes border when clicking on advisory box
    box.addEventListener("click", function () {
        this.style.border = "2px solid blue";
    });

    // Ondblclick event: Expands advisory box smoothly
    box.addEventListener("dblclick", function () {
        this.style.height = "auto";
        this.style.transition = "height 0.3s ease";
        this.style.border = "2px solid green";
    });
});

// Onclick event: Alerts when clicking on "Read" or "Watch" links in #resources
document.querySelectorAll("#resources a").forEach(link => {
    link.addEventListener("click", function (event) {
        event.preventDefault();
        alert("You clicked on a resource link.");
    });
});

// Onchange event: Alerts only for dropdowns and checkboxes
document.querySelectorAll("select, input[type='checkbox']").forEach(input => {
    input.addEventListener("change", function () {
        alert(`Value changed in: ${this.name}`);
    });
});
