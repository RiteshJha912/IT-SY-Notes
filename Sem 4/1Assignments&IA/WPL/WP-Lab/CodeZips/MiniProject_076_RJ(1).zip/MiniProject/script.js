document.addEventListener("DOMContentLoaded", function () {
    console.log("✅ DOM Loaded - Initializing Event Listeners...");

    // Show welcome message only on the home page
    if (window.location.pathname === "/" || window.location.pathname.includes("index.html")) {
        alert("Welcome to the Cyber Awareness Portal!");
    }

    // Onblur event: Alerts when input loses focus (ONLY for text fields)
    document.querySelectorAll("input[type='text']").forEach(input => {
        input.addEventListener("blur", function () {
            alert(`You left the field: ${this.name}`);
        });
    });

    // Onreset event: Confirms before resetting the form
    document.querySelectorAll("form").forEach(form => {
        form.addEventListener("reset", function (event) {
            if (!confirm("Are you sure you want to reset the form?")) {
                event.preventDefault();
            }
        });
    });

    // Onmouseover event: Changes color when hovering over advisory boxes
    document.querySelectorAll(".box").forEach(box => {
        box.addEventListener("mouseover", function () {
            console.log("🔍 Mouseover detected on:", this);
            this.style.backgroundColor = "#dfe6f1";
        });

        // Onmouseout event: Resets the background color
        box.addEventListener("mouseout", function () {
            this.style.backgroundColor = "#ffffff";
        });

        // Onclick event: Changes border when clicking on advisory box
        box.addEventListener("click", function () {
            console.log("🖱 Click event detected on:", this);
            this.style.border = "2px solid blue";  // Blue border on click
        });

        //  Ondblclick event: Expands advisory box smoothly
        box.addEventListener("dblclick", function () {
            console.log("🖱 Double-click event detected on:", this);
            this.style.height = "auto";
            this.style.transition = "height 0.3s ease";
            this.style.border = "2px solid green";  // Green border on double-click
        });
    });

    // Onclick event: Alerts when clicking on "Read" or "Watch" links in #resources
    document.querySelectorAll("#resources a").forEach(link => {
        link.addEventListener("click", function (event) {
            event.preventDefault(); // Prevents unnecessary page reload
            alert("You clicked on a resource link.");
        });
    });

    // Onchange event: Alerts only for dropdowns and checkboxes (to avoid too many alerts)
    document.querySelectorAll("select, input[type='checkbox']").forEach(input => {
        input.addEventListener("change", function () {
            alert(`Value changed in: ${this.name}`);
        });
    });

    console.log("✅ Event listeners attached successfully!");
});
